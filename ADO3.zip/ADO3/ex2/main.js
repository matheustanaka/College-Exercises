function newText() {
    document.getElementById("h3").innerHTML = "olha só quem apareceu ... um header nível 3 :D";
}