//Function to set new image
function setNewImg(){
    document.getElementById('img1').src = "./img/19.jpg"
}
//Function to set old image
function setOldImg(){
    document.getElementById('img1').src = "./img/14.jpg"
}