# 1. Crie uma página com uma calculadora para converter graus Celsius em Fahrenheit. A calculadora deve ter um campo para digitar o valor em Celsius e apresentar, na mesma página, o resultado em Fahrenheit.
        A fórmula é: fahrenheit = (celsius * (1.8)) + 32


### Link that I follow the example: https://www.youtube.com/watch?v=lkSzVUBQPzU